package cc1;

import java.io.FileWriter;
import java.io.IOException;

public class generate_test_ip 
{

	public generate_test_ip() 
	{
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws IOException
	{
		// TODO Auto-generated method stub
	    String filename= "/Users/US-JZhai/Desktop/selftest/testip3million.csv";
	    FileWriter fw = null;
		try {
			fw = new FileWriter(filename,true);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} //the true will append the new data
		
		for (int i = 0; i<3000000; i++)
		{		 
			int ip1 = (int)(Math.random()*255);
			int ip2 = (int)(Math.random()*255);
			int ip3 = (int)(Math.random()*255);
			int ip4 = (int)(Math.random()*255);
			String ip=ip1+"."+ip2+"."+ip3+"."+ip4;
			fw.write(ip +"\n");//appends the string to the file
		}
		fw.close();
		System.out.println("Files wrote out");


	}

}
